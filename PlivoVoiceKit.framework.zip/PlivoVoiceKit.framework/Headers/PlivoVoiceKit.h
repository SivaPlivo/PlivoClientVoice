//
//  PlivoVoiceKit.h
//  PlivoVoiceKit
//
//  Created by Siva  on 14/04/17.
//  Copyright © 2017 Plivo. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "PlivoEndpoint.h"

//! Project version number for PlivoVoiceKit.
FOUNDATION_EXPORT double PlivoVoiceKitVersionNumber;

//! Project version string for PlivoVoiceKit.
FOUNDATION_EXPORT const unsigned char PlivoVoiceKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PlivoVoiceKit/PublicHeader.h>


